package com.example.norri.foodsforanxiety2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.norri.foodsforanxiety2.R;

public class MainActivity extends AppCompatActivity {
    ImageButton androidImageButton, androidImageButton1, androidImageButton2, androidImageButton3;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        /*androidImageButton = (ImageButton) findViewById(R.id.wild_salmon);
        androidImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                Intent intent = new Intent(getBaseContext(), NextActivity.class);
                startActivity(intent);
            }
        });*/
        ImageButton buttonApply = findViewById(R.id.wild_salmon);
        buttonApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), NextActivity.class);
                startActivity(intent);
            }
        });

        androidImageButton1 = (ImageButton) findViewById(R.id.avocado);
        androidImageButton1.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                Toast.makeText(MainActivity.this, "Avocado", Toast.LENGTH_LONG).show();
                textView.setText("Healthy fats and vitamin B help reduce stress.");
            }
        });

        textView = findViewById(R.id.text_view);
        androidImageButton2 = (ImageButton) findViewById(R.id.dark);
        androidImageButton2.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                textView.setText("Improves blood flow to the brain increase the ability to cope with stress.");
                Toast.makeText(MainActivity.this, "Dark Chocolate", Toast.LENGTH_LONG).show();
            }
        });


        androidImageButton3 = (ImageButton) findViewById(R.id.green_tea);
        androidImageButton3.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){
                textView.setText("L-theanine causes a reduction in phychological stress.");
                Toast.makeText(MainActivity.this, "Green Tea", Toast.LENGTH_LONG).show();
            }
        });
    }
    @Override
    public void onBackPressed() {
        finish();
        Intent intent = new Intent(getBaseContext(), MainActivity.class);
        startActivity(intent);
    }


}


