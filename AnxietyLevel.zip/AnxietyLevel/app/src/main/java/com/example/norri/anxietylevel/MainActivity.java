package com.example.norri.anxietylevel;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity{

    RadioGroup radioGroup2;
    RadioButton radioButton;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroup2 = findViewById(R.id.radioGroup2);

        textView = findViewById(R.id.text_view);

        Button buttonApply = findViewById(R.id.button_select);
        buttonApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int radioId = radioGroup2.getCheckedRadioButtonId();
                radioButton = findViewById(radioId);
                Intent intent = new Intent(getBaseContext(), NextActivity.class);
                int selectedRadioButtonID = radioGroup2.getCheckedRadioButtonId();
                RadioButton selectedRadioButton = (RadioButton) findViewById(selectedRadioButtonID);
                String s = selectedRadioButton.getText().toString();
                Log.d("value found", s);
                intent.putExtra("Patient_Disease", s);

                startActivity(intent);
            }
        });
    }
}



