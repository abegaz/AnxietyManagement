package com.example.norri.anxietylevel;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class NextActivity extends AppCompatActivity {
    RadioGroup radioGroup;
    RadioButton radioButton;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.next_activity);

        radioGroup = findViewById(R.id.radioGroup);

        textView = findViewById(R.id.text_view);
        Intent intent = getIntent();
        String anxietyLevel = intent.getStringExtra("Patient_Disease");
        Log.d("found again", anxietyLevel);
        textView.setText(anxietyLevel);

        Button buttonApply = findViewById(R.id.button_select);
        buttonApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getBaseContext(), NextActivity2.class);

                startActivity(intent);
            }
        });

    }

    public void checkButton(View view) {
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);




        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.radio_ten:
                if (checked)
                    Toast.makeText(this, "TEN" + radioButton.getText(), Toast.LENGTH_SHORT).show();
                break;
            case R.id.radio_nine:
                if (checked)
                    Toast.makeText(this, "NINE", Toast.LENGTH_SHORT).show();
                break;
            case R.id.radio_eight:
                if (checked)
                    Toast.makeText(this, "EIGHT", Toast.LENGTH_SHORT).show();
                break;
            case R.id.radio_seven:
                if (checked)
                    Toast.makeText(this, "SEVEN", Toast.LENGTH_SHORT).show();
                break;
            case R.id.radio_six:
                if (checked)
                    Toast.makeText(this, "SIX", Toast.LENGTH_SHORT).show();
                break;
            case R.id.radio_five:
                if (checked)
                    Toast.makeText(this, "FIVE", Toast.LENGTH_SHORT).show();
                break;
            case R.id.radio_four:
                if (checked)
                    Toast.makeText(this, "FOUR", Toast.LENGTH_SHORT).show();
                break;
            case R.id.radio_three:
                if (checked)
                    Toast.makeText(this, "THREE", Toast.LENGTH_SHORT).show();
                break;
            case R.id.radio_two:
                if (checked)
                    Toast.makeText(this, "TWO", Toast.LENGTH_SHORT).show();
                break;
            case R.id.radio_one:
                if (checked)
                    Toast.makeText(this, "ONE", Toast.LENGTH_SHORT).show();
                break;}


    }
}


    /*public void checkButton(View v) {
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        Toast.makeText(this, "Selected: " + radioButton.getText(), Toast.LENGTH_SHORT).show();
    }*/
