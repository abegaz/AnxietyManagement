package com.example.norri.anxietylevel;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class NextActivity2 extends AppCompatActivity {
    TextView textView;
    LinearLayout linearLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.breathing_exercise);
        //textView = findViewById(R.id.text_view_selected);
        linearLayout = findViewById(R.id.text_view_selected);
    }
}