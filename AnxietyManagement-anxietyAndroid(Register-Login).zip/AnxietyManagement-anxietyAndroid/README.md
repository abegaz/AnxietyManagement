# AnxietyManagement-
Project objective: To develop a secure and usable AI based anxiety management system that supports people in reducing anxiety due to loneliness
