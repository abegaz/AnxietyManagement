package ung.csci.a3300.anxietymanagement.view

import android.content.Intent
import android.media.MediaPlayer
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import ung.csci.a3300.anxietymanagement.R
import android.R.raw
import android.widget.*
import android.widget.ListView
import android.widget.ListAdapter
import android.widget.ArrayAdapter
import android.widget.AdapterView
import kotlinx.android.synthetic.main.activity_games.*

class register : AppCompatActivity() {
//    public var mainSceneReady = false;
    internal lateinit var listview: ListView
    internal lateinit var list: MutableList<String>
    internal lateinit var adapter: ListAdapter
    internal var mediaPlayer: MediaPlayer? = null

    @Override
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register)

        listview = findViewById<View>(R.id.listview) as ListView
        list = ArrayList()

        val playBtn = findViewById<Button>(R.id.play)
        val submitBtn = findViewById<Button>(R.id.submit)
        var clickListener = View.OnClickListener { view ->
            when (view.getId()) {
                R.id.submit -> openLogin()
//                R.id.playBtn -> muteMusic()

            }
        }

        val fields = R.raw::class.java!!.getFields()
        for (i in fields.indices) {
            list.add(fields[i].getName())
        }

        adapter = ArrayAdapter (this, android.R.layout.simple_list_item_1,list)
        listview.adapter = adapter

        listview.onItemClickListener = AdapterView.OnItemClickListener{adapterView, view, i , 1 ->
            if (mediaPlayer != null)
                mediaPlayer !!.release()
        }

        val singh = resources .getIdentifier(list[i], "raw", packageName)
        mediaPlayer = MediaPlayer.create(this,singh)
        mediaPlayer !!.start()
        //        public void playBtnClick (View view)

        playBtn.setOnClickListener(clickListener)
        submitBtn.setOnClickListener(clickListener)

    }


    fun openLogin() {
        val intent = Intent(this@register, MainActivity::class.java)
        finish()
        startActivity(intent)
    }

    fun muteMusic() {
        val intent = Intent(this@register, MainActivity::class.java)
        finish()
        startActivity(intent)

//        if (!mp.isPlaying()){
//                mp.start();
//                playBtn.setBackground(R.drawable.stop);
//            }
//            else {
//                mp.pause();
//                playBtn.setBackground(R.drawable.play);
//            }
    }
}


