//package ung.csci.a3300.anxietymanagement.model;
//
//import android.media.MediaPlayer;
//import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
//import android.widget.Button;
//import ung.csci.a3300.anxietymanagement.R;
//
//public class model extends AppCompatActivity {
//
//    Button playBtn;
//    MediaPlayer mp;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        playBtn = (Button) findViewById(R.id.playBtn);
//
//        mp = MediaPlayer.create(this, R.raw.music);
//
//        public void playBtnClick (View view)
//        {
//            if (!mp.isPlaying()){
//                mp.start();
//                playBtn.setBackground(R.drawable.stop);
//            }
//            else {
//                mp.pause();
//                playBtn.setBackground(R.drawable.play);
//            }
//        }
//
//
//
//    }
//}
