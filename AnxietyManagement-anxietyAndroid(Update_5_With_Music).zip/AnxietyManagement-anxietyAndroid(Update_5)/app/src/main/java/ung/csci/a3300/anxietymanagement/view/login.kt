package ung.csci.a3300.anxietymanagement.view

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import ung.csci.a3300.anxietymanagement.R
import kotlinx.android.synthetic.main.activity_games.*

class login : AppCompatActivity() {
    public var mainSceneReady = false;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.login)
        val loginBtn = findViewById<Button>(R.id.login_button)
        val registerBtn = findViewById<Button>(R.id.register_button)
        var clickListener = View.OnClickListener { view ->
            when (view.getId()) {
                R.id.login_button -> openRegister()
                R.id.register_button -> openRegister()

            }
        }
        loginBtn.setOnClickListener(clickListener)
        registerBtn.setOnClickListener(clickListener)

    }

    fun openRegister() {
        val intent = Intent(this@login, MainActivity::class.java)
        finish()
        startActivity(intent)
    }

//    fun openRegister() {
//        val intent = Intent(this@login, MainActivity::class.java)
//        finish()
//        startActivity(intent)
//    }
}