package ung.csci.a3300.anxietymanagement.controller;

import android.app.Activity;
import android.content.Intent;
import android.widget.TextView;
import ung.csci.a3300.anxietymanagement.R;
import android.widget.Button;
import android.view.View;
import android.app.Activity;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import ung.csci.a3300.anxietymanagement.view.MainActivity;

public class gamesPage extends AppCompatActivity {


//        String[] Games = {"Proteus","Abzu","Journey","Farming Simulator", "Meadow"};
//        // "Proteus","Abzu","Journey","Farming Simulator", "Meadow" wtf are these? its about loneliness not walking through a park
//        TextView text = (TextView) findViewById(R.id.text_display);
//        Button button = (Button) findViewById(R.id.nextGame_button);
//        Intent intent = new Intent(gamesPage.this, MainActivity.class);
////        button.setOnClickListener(new View.OnClickListener){
////            public void onClick(View view){
////                buttonClickGamepage();
////            }
////        }
//
//        public String getGame(){
//            int value = (int)(Math.random()* Games.length)-1;
//            String game = Games[value];
//            return game;
//
//        }
//        public void buttonClickGamepage(){
//            String game = getGame();
//            text.setText("have you tried playing " + game + "?");
//
//        }



    }

